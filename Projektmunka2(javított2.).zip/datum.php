<style>
    #datum {
        position: absolute;
        top: 0;
        right: 10px;
    }

    #ido {
        position: absolute;
        top: 30px;
        right: 20px;
    }
    }
</style>

<p id=datum> <?php echo date("Y.m.d.") ?> </p>
<p id=ido> <?php echo date("H:i") ?> </p>