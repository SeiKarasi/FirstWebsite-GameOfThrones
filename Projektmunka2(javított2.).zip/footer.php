<style>
footer {
            position: absolute;
            bottom: 0;
            text-align: center;
            font-size: x-large;
            left: 600px;
            color: white;
            font-size: 18px;
        }
</style>

<footer>
        <address>
            <p>A weboldal szerkesztői: Sánta Tamás & Pál Krisztián Zoltán</p>
            <p>Elérhetőség: <a href="mailto:Valaki@example.com">Valaki@example.com</a>.</p>
        </address>
</footer>